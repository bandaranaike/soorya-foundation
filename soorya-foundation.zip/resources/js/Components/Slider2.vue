<template>
    <SliderItem title=" Upgrading Sunday schools (Dhamma school)"
                description="Conducting Sunday school teacher training programmers and supporting them by offering official badges and essentials" image="sl-2.jpg"></SliderItem>
</template>

<script setup>

import SliderItem from "@/Components/SliderItem";
</script>

