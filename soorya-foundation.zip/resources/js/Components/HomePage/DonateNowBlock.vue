<template>
    <div class="bg-gray-800 text-white text-center poppins-font">
        <div class="max-w-6xl lg:px-8 py-24 mx-auto">
            <h3 class="text-5xl font-bold leading-normal">Your help will change their lives. Let’s feed the future </h3>
            <p class="mt-8 px-24 inline-block leading-7">We’ve moving Sri Lanka towards a fairer, flourishing and just Tomorrow. But we can’t get there without you. Thank you for helping us support the</p>
            <a href="#" class="bg-amber-500 px-8 py-4 mt-8 rounded-full inline-block">Make Donation Today</a>
        </div>
    </div>
</template>

<script setup>

</script>

<style>

</style>
