<template>
    <SliderItem title="Great futures are built with a small charity" description="We are helping students who like to learn arts, curving and cultural crafts"
                image="sl-1.jpg"></SliderItem>
</template>

<script setup>

import SliderItem from "@/Components/SliderItem";
</script>
